const Analysis = () => {
  return (
    <>
      <p>Analysis</p>
    </>
  );
};

export default Analysis;
