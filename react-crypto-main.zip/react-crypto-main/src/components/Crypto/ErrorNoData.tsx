const ErrorNoData = () => {
  return (
    <>
      <p>ErrorNoData</p>
    </>
  );
};

export default ErrorNoData;
