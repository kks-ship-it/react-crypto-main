const Spinner = () => {
  return <div className="spinner-6 -mt-0 m-auto "></div>;
};

export default Spinner;
