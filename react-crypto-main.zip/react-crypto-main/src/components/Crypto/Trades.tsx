const Trades = () => {
  return (
    <>
      <p>Trades</p>
    </>
  );
};

export default Trades;
