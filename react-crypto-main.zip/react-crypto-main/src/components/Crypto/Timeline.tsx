const Timeline = () => {
  return (
    <>
      <p>Timeline</p>
    </>
  );
};

export default Timeline;
