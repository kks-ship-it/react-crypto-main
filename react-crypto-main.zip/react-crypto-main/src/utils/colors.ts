export const Primary: string = "#1f90ff";
export const Light: string = "rgba(56, 62, 70, 0.3)";
export const Lighter: string = "rgb(64, 71, 80)";
export const White: string = "#fff";
export const Navy: string = "#1b1f26";
